package helpers.mail;

import helpers.Helper;

import java.util.Vector;

import persistencia.dominio.Persona;
import server.mail.ControlGestionCuentasCorreo;
import utils.Utils;
import utils.mail.EnviarMailGmail;
import utils.mail.MailSIAT;
import cliente.pagina.Pagina;

import comun.constantes.ACCIONES_A_REALIZAR;
import comun.constantes.PARAMETROS_PAGINAS;

public class HelperGestionCuentasCorreo extends Helper {
	ControlGestionCuentasCorreo controlCuentasCorreo = null;

	public HelperGestionCuentasCorreo(Pagina pagina) {
		super(pagina);
		controlCuentasCorreo = new  ControlGestionCuentasCorreo(this.persistencia);
	}

	public String generarHTMLGestionCuentasCorreo()throws Exception{
		String html = "";

		html += "  <form method=\"post\" name=\"gestionarCuentasCorreo\" id=\"gestionarCuentasCorreo\" action=\""+this.pagina.getVistaContenido().getPathNombrePagina()+"\">\n";
		Vector personas = controlCuentasCorreo.obtenerUsuariosSinCorreo();
		html+="<input name=\""+PARAMETROS_PAGINAS.ACCION2+"\" id=\""+PARAMETROS_PAGINAS.ACCION2+"\" type=\"hidden\" value=\"\" />";
		html+="<script type=\"text/javascript\" charset=\"utf-8\">\n";
		html += Utils.scriptOrdenarDataTableFecha();
		html+="   $(document).ready( function () {\n"; 			  
		html+="      $(\"#tablapersonas\").dataTable({\n";
		html += 			"\"sScrollX\": \"100%\",\n";
		html += 			"\"sScrollInfinite\": true,\n"; //MLucero
		html += 			"\"bScrollCollapse\": true,\n";
		html +="			 \"bJQueryUI\": true,\n";
		html += 			"\"sPaginationType\": \"full_numbers\",";  
		//html += 		 	"\"aaSorting\": [[ 2, \"asc\" ]],\n";
		html += 			"\"iDisplayLength\": 25,";
		html+="			\"sDom\": '<\"H\"Tlfr>t<\"F\"ip>',\n";
		html+="			\"oTableTools\": {\n";
		html+="				\"sSwfPath\": \""+this.pagina.getPathRaiz()+"js/jQuery/pluging/tablas/DataTables-1.9.0/extras/TableTools/media/swf/copy_cvs_xls_pdf.swf\",\n";
		html+="				\"aButtons\": [	\"copy\", \"csv\", \"xls\", \"pdf\", \"print\"]\n";
		html+="			},\n";
		html +="			\"aoColumns\": [\n";					
		html +="			  {\"bSortable\": true},\n";
		html +="			  {\"bSortable\": true},\n";
		html +="			  {\"bSortable\": true},\n";
		html +="			  {\"bSortable\": true},\n";
		html +="			  {\"sType\":\"date-eu\"},\n";
		html +="			  {\"bSortable\": true},\n";
		html +="			  {\"bSortable\": false},\n";
		html +="			  {\"bSortable\": false}\n";
		html +="			  ]\n";
		html+="       });\n";
		html+="    });\n";
		html+="</script>\n";
		
		html += "  <script type=\"text/javascript\" src=\""+this.pagina.getPathRaiz()+"js/mail/mails_gestion_cuentas.js?version="+server.Server.VERSION_SIAT+"\"></script> \n";

		html += "<div id=\"container_contactos\" style=\"float:right;\">\n";/**/
		html += "<div id=\"dt_example\" >\n";/**/
		html += "<div id=\"container\" >\n";///style=\"width:750px;overflow-x: scroll;height:auto;\"

		//html += "    <div id=\"tablaGris\">\n";
		html += "    <table class=\"displaytabletools\" id=\"tablapersonas\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> \n";
		html += "  <thead>\n";
		html += "     <tr>\n";
		html += "      <th>N&ordm;</th> " +
				"<th>Apellido</th> " +
				"<th>Nombre</th> " +
				"<th style=\"width:70px;\" >D.N.I.</th> " +
				"<th>Fecha Ingreso</th>" +
				"<th>Login</th>" +
				"<th>Mail</th> " +
				"<th><input name=\""+PARAMETROS_PAGINAS.CHECKBOX_TODOS+"\" onClick=\"todasCuentasCorreo()\" type=\"checkbox\" value=\"Todas\"></th>\n"; 
		html += "     </tr>\n";
		html += "  </thead>\n";
		html += "  <tbody>\n";
		for(int i=0;i<personas.size();i++){
			Persona pers = (Persona)personas.elementAt(i);
			html += "     <tr >\n";
			html += "       <td>" +(i+1)+ "</td><td>" + pers.getApellido() + "</td><td>" + pers.getNombre() + "</td><td>"+pers.getNumeroDoc()+"</td>";
			html += "       <td>"+utils.Utils.getStrSqlDate(pers.getFechaIngreso())+"</td>";
			html += "       <td>" + pers.getLogin()+" </td>\n";
			
			//Icono correo por cada persona
			String mailPersona=EnviarMailGmail.obtenerMailPersona(pers);
			String htmlMail="";
			if(mailPersona.compareTo("")!=0){
				htmlMail = "       <a style=\"cursor:pointer\" "+MailSIAT.onClicEnvioMail(ACCIONES_A_REALIZAR.ENVIAR_MAILITO, "", ""+mailPersona+"","","")+">"+
							"<img src=\""+this.pagina.getPathLogoMensajeNuevo()+"\" title=\"Enviar correo\"> </a>\n";
			}   
			html += "<td>" + htmlMail +" </td>";
			html += "        <td> <input name=\""+PARAMETROS_PAGINAS.IDS_PERSONAS+"\" id=\""+PARAMETROS_PAGINAS.IDS_PERSONAS+"\" type=\"checkbox\" value=\""+pers.getId()+"\" > </td>\n";    	  
			html += "     </tr>\n";
		}
		html += "  </tbody>\n";
		html += "  </table><br/>\n";
		html += " </div>\n";
		html += " </div>\n";
		html += " </div>\n";

		html += "  <script type=\"text/javascript\" src=\""+this.pagina.getPathRaiz()+"js/grupo/comun_formulario.js\"></script> \n";
		html += " <br> <p align=\"center\">\n";
		html += " <input class=\"input\" type=\"button\" name=\"Cancelar\" onClick=\"history.back();\" value=\"Volver\">";
		html += " &nbsp;&nbsp;&#8226;&nbsp;&nbsp;<input class=\"input\" type=\"button\" name=\"VerificarCuentas\" onClick=\"realizaSubmitConfirmarCuentasCorreo('"+ACCIONES_A_REALIZAR.VERIFICAR+"');\" value=\"Verificar Cuentas\">"+
		 " &nbsp;&nbsp;&#8226;&nbsp;&nbsp;<input class=\"input\" type=\"button\" name=\"ConfirmarCuentas\" onClick=\"realizaSubmitConfirmarCuentasCorreo('"+ACCIONES_A_REALIZAR.ACEPTAR+"');\" value=\"Confirmar Cuentas\">"+	    	 
				"  </p>";	    	 
		html += "  </form>\n";
		html += " </div>\n";
		return html;
	}

	public String confirmarCuentasCorreo()throws Exception{
		String[] personasSelecc = this.pagina.getParameterValues(PARAMETROS_PAGINAS.IDS_PERSONAS);
		return controlCuentasCorreo.confirmarCuentasCorreo(personasSelecc); 
	}

	protected String getHTMLReferenciasParametros(){
		String html = PARAMETROS_PAGINAS.REFRESH+"="+new Long((new java.util.Date()).getTime());
		return html;
	}

	public String verificarCuentasCorreo() throws Exception {
		String[] personasSelecc = this.pagina.getParameterValues(PARAMETROS_PAGINAS.IDS_PERSONAS);
		return controlCuentasCorreo.verificarCuentasCorreo(personasSelecc); 
	}  

}