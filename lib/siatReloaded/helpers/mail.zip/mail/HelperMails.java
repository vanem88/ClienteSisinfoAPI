package helpers.mail;

import java.sql.ResultSet;

import procesos.ThreadMail;
import comun.constantes.CONSTANTES_FINALES;
import comun.constantes.CONSTANTES_FINALES_STRING;
import comun.constantes.TIPO_USUARIOS;
import server.Server;
import server.general.ControlGeneral;
import utils.mail.EnviarMailGmail;
import helpers.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class HelperMails extends Helper{
   
  public HelperMails() {
	  super();
  }  
  
  /**METODO QUE SE INVOCAR� DESDE POPUP DE ENV�O DE MAILS.
   * @param asunto
   * @param mensaje
   * @param para: Me indicar� los destinatarios que recibiran el correo dentro del nivel (idNivel).
   * @param idNivel: puede ser una Organizaci�n, un Aula o una Comision. Para el WebMaster puede ser tambien el Campus. 
   * @param comision: me indica si el idNivel es o no de una Comision
   * @throws Exception
   */
  
  /*
  
  public void envioMasivoDeMails(String asunto,String mensaje,String para,Long idNivel,boolean comision) throws Exception{
	  ControlGeneral controlGeneral = new ControlGeneral(this.persistencia,this.getConexionSQL());
	  ResultSet resul = null;
	  if(para.compareTo(CONSTANTES_FINALES_STRING.TODOS_USUARIOS)==0){
		  resul = controlGeneral.getTodosUsuariosRecibenMail();
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.USUARIOS_ULTIMOS_3_MESES)==0){
		  resul = controlGeneral.getUsuariosRecibenMailUltimosMeses(3);
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.USUARIOS_ULTIMOS_6_MESES)==0){
		  resul = controlGeneral.getUsuariosRecibenMailUltimosMeses(6);
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.USUARIOS_ULTIMO_ANIO)==0){
		  resul = controlGeneral.getUsuariosRecibenMailUltimosMeses(12);
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.ADMINISTRADORES)==0){
		  resul = controlGeneral.getTodosTiposUsuariosRecibenMail(TIPO_USUARIOS.ADMINISTRADOR);
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.ALUMNOS)==0){		  
		  resul = controlGeneral.getTodosTiposUsuariosRecibenMail(TIPO_USUARIOS.ALUMNO);
	  }else if(para.compareTo(CONSTANTES_FINALES_STRING.DOCENTES)==0){		  
		  resul = controlGeneral.getTodosTiposUsuariosRecibenMail(TIPO_USUARIOS.DOCENTE);
	  }
	  //Para corroborar cuales son las direcciones a las cuales se enviar�n los correos masivos.
	  //System.out.println("ASUNTO: "+ asunto);
	  //System.out.println("CUERPO: "+ mensaje);
	  //String email = null;
	  //int i = 1;
	  //if(resul != null){
   		//  while (resul.next()){
   		//	  email = resul.getString("email");
   		//	  System.out.println(i+") "+email);
   		//	  i++;
   		//  }
	  //}	  
	  this.envioMasivo(resul,asunto,mensaje);	   
  }
  
  public void envioMasivo(ResultSet resul,String asunto, String mensaje){
	  String apellido = null;
	  String nombre = null;
	  String email = null;
	  String formatoInfoMail = null;	  
	  String cuerpo = "";
	  //Para alternaci�n de cuentas de Gmail que son Adminsitradoras	  
	  String [] from = {CONSTANTES_FINALES.CUENTAS_ADMINISTRADORAS};
	  int [] contador = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};	  
	  if(CONSTANTES_FINALES.CUENTAS_ADMINISTRADORAS.indexOf(",")> -1) from = CONSTANTES_FINALES.CUENTAS_ADMINISTRADORAS.split(",");
	  int vuelta = 0;
	  int contadorMailsParaIntervalo = 0;
	  int contadorTotal = 0;
	  int indiceCuentasNuestras = -1;
	  String remitente = "";
	  //-------------------------------------------------------------	    
   	  if(resul != null){
   		  try {
			while (resul.next()){
				  email = resul.getString("email");
				  nombre = resul.getString("nombre");
				  apellido = resul.getString("apellido");
				  formatoInfoMail = resul.getString("formato_info");
				  //---------------------------------------------------Para alternaci�n de cuentas de Gmail que son Adminsitradoras---------------------------------------------------
				  //Intervalo de tiempo sin enviar mails por las dudas.			
				  if(contadorMailsParaIntervalo==500){//A los 500 mails enviados espera 30 segundos.
					  System.out.println("INICIA ESPERA del THREAD...");
					  Thread.sleep(30*1000);
					  System.out.println("TERMINA ESPERA del THREAD...");
					  contadorMailsParaIntervalo = 0;					  
				  }

				  //Ciclado para rotar direcciones remitentes y enviar mails. Va enviando de a un mail por cada cuenta. En este paso cambiamos a la siguiente cuenta como Remitente.				  
				  if(indiceCuentasNuestras==from.length-1)
					  indiceCuentasNuestras=0;
				  else indiceCuentasNuestras++;   	
				  
				  System.out.println("--------------------------------------------------------------------------------------------------");
				  //System.out.println("from.length: "+from.length);
				  //System.out.println("contador.length: "+contador.length);
				  //System.out.println("indiceCuentasNuestras: "+indiceCuentasNuestras);
				  System.out.println("vuelta: "+vuelta);
				  System.out.println("contadorMailsParaIntervalo: "+contadorMailsParaIntervalo);
				  System.out.println("--------------------------------------------------------------------------------------------------");   			  
				  
				  //Con esto vamos controlando que con cada cuenta no se supere el limite de mails establecido por nosotros.
				  while(contador[indiceCuentasNuestras]>=Server.CANTIDAD_CORREOS_POR_MAIL && vuelta<=from.length){
					  //Estamos en el ciclo porque la cuenta corriente alcanzo el limite de env�os diarios. 
					  if(indiceCuentasNuestras==from.length)
						  indiceCuentasNuestras=0;
					  else indiceCuentasNuestras++;
					  vuelta++;
				  }
				  //Encontramos una cuenta que aun no ha llegado al limite de los env�os.
				  if(contador[indiceCuentasNuestras]<Server.CANTIDAD_CORREOS_POR_MAIL){
					  remitente = from[indiceCuentasNuestras];
					  contador[indiceCuentasNuestras]=contador[indiceCuentasNuestras]+1;
					  System.out.println("REMITENTE: "+remitente);
					  System.out.println("ENVIADOS POR REMITENTE: "+contador[indiceCuentasNuestras]);
					  vuelta=0;			
					  if(formatoInfoMail.compareTo(CONSTANTES_FINALES_STRING.FORMATO_HTML)==0){
						  	cuerpo =  "<html>\n";
						  	cuerpo += "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
						  	cuerpo += "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
						  	cuerpo += "<p><img alt=\"Sistema de Apoyo a la Teleformaci�n\" src=\"http://www.siat.unrc.edu.ar/siat2/imagenes/cabecera.png\"></p>";   				  	
						  	cuerpo += "<label>Hola <b>"+nombre+" "+apellido+": </b><br>";
						  	cuerpo += mensaje+"</label><br>";					  	  	
					  	  	new ThreadMail(true,email,asunto,cuerpo,remitente,formatoInfoMail).start();
					  }else{
						  cuerpo = "Hola "+nombre+" "+apellido+": \n";
						  cuerpo += mensaje+"\n";
						  new ThreadMail(true,email,asunto,cuerpo,remitente,formatoInfoMail).start();
					  }
					  contadorTotal++;
					  contadorMailsParaIntervalo++;
					  System.out.println("=======================>>>> CANTIDAD DE MAILS ENVIADOS HASTA EL MOMENTO: "+contadorTotal);
				  }else{
					  //No tenemos alguna cuenta que no haya superado la cantidad de env�os diarios.
					  System.out.println("Nos quedamos sin cuentas administradoras para que env�en mails diarios. Todas superaron el limite puesto por nosotros.");
					  new ThreadMail(true,"npereyra@rec.unrc.edu.ar",
							  "Problema cuentas ADMINISTRADORAS del SIAT en Google",
							  "Nos quedamos sin cuentas administradoras para que se env�en mails diarios. Todas las cuentas nuestras superaron el limite puesto por nosotros, el cual es: "+Server.CANTIDAD_CORREOS_POR_MAIL+".",
							  "info@siat.unrc.edu.ar",CONSTANTES_FINALES_STRING.FORMATO_HTML).start();
					  new ThreadMail(true,"jconde@rec.unrc.edu.ar",
							  "Problema cuentas ADMINISTRADORAS del SIAT en Google",
							  "Nos quedamos sin cuentas administradoras para que se env�en mails diarios. Todas las cuentas nuestras superaron el limite puesto por nosotros, el cual es: "+Server.CANTIDAD_CORREOS_POR_MAIL+".",
							  "info@siat.unrc.edu.ar",CONSTANTES_FINALES_STRING.FORMATO_HTML).start();
					  new ThreadMail(true,"nhuelpereyra@gmail.com",
							  "Problema cuentas ADMINISTRADORAS del SIAT en Google",
							  "Nos quedamos sin cuentas administradoras para que se env�en mails diarios. Todas las cuentas nuestras superaron el limite puesto por nosotros, el cual es: "+Server.CANTIDAD_CORREOS_POR_MAIL+".",
							  "info@siat.unrc.edu.ar",CONSTANTES_FINALES_STRING.FORMATO_HTML).start();
					return;
				  }
			  }
		} catch (Exception e) {			
			e.printStackTrace();
		}
   		ControlGeneral controlGeneral = new ControlGeneral(this.persistencia);
   		controlGeneral.acentarRegistrosEnviosDeCorreos(contador);
   	  }
   	  return;
  }
  
  */
}